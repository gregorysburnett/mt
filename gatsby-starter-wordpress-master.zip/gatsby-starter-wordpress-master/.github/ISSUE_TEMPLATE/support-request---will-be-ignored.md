---
name: Support request - WILL BE IGNORED
about: We do not provide free technical support here. Try StackOverflow / Gatsby Discord
title: ''
labels: support
assignees: ''

---

Any issues submitted through this template will be closed without comment. If you find a bug, or wish to request a feature, please file one of those issues.

We don't have the resources to provide technical support free of charge. StackOverflow or Gatsby's discord server are good places to try.

If you would like to volunteer to provide tech support for free in this repo, please open an issue and we'll reach out.
